執行：在Terminal裏面執行 ./Email

按照步驟執行：
1. 輸入NTUST賬號(不需要@後面的mail位置)
2. 輸入NTUST密碼
3. 輸入傳送Email
4. 輸入接收Email
5. 輸入主旨
6. 輸入内容(以一單獨句點.的新行做結尾)
7. 完成

執行範例：./Email 
NEED TO LOG IN YOUR NTUST ACOUNT
username: B11115032
password: ***********
Login success!
From: example@gmail.com
To: example2@gmail.com
Subject: hey yo
Content: 
(end with a single dot)
hey yo bro
.
Send success!

輸出： 如上所示 + 所接收Email

編譯：在Terminal裏面執行 g++ email.cpp -o Email

